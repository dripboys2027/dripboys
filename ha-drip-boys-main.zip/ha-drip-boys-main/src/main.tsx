import '@vly-ai/integrations';
import { Toaster } from "@/components/ui/sonner";
import { StoreLayout } from "@/components/store/StoreLayout";
import { LanguageProvider } from "@/lib/i18n";
import { CartProvider } from "@/lib/store-state";
import { VlyToolbar } from "../vly-toolbar-readonly.tsx";
import { ConvexAuthProvider } from "@convex-dev/auth/react";
import { ConvexReactClient } from "convex/react";
import React, { StrictMode, useEffect, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes, useLocation } from "react-router";
import "./index.css";

// Lazy load route components for better code splitting
const Landing = lazy(() => import("./pages/Landing.tsx"));
const Shop = lazy(() => import("./pages/Shop.tsx"));
const ProductDetails = lazy(() => import("./pages/ProductDetails.tsx"));
const CategoryPage = lazy(() => import("./pages/CategoryPage.tsx"));
const Admin = lazy(() => import("./pages/Admin.tsx"));
const NotFound = lazy(() => import("./pages/NotFound.tsx"));

// Simple loading fallback for route transitions
function RouteLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-pulse text-muted-foreground">Loading...</div>
    </div>
  );
}

/** Silent error boundary — if VlyToolbar crashes it renders nothing instead of
 *  crashing the whole app (e.g. hook errors in WebContainer environment). */
class ToolbarErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(err: Error) {
    console.warn("[VlyToolbar] Caught error, toolbar disabled:", err.message);
  }
  render() {
    return this.state.hasError ? null : this.props.children;
  }
}

/** Chunk/network load failures (offline user) get a small friendly screen. */
function isModuleLoadError(message: string): boolean {
  const needle = message.toLowerCase();
  return (
    needle.includes("dynamically imported module") ||
    needle.includes("failed to fetch dynamically") ||
    needle.includes("error loading dynamically") ||
    needle.includes("loading chunk") ||
    needle.includes("importing a module") ||
    (needle.includes("networkerror") && needle.includes("fetch"))
  );
}

/** Hard guard so runtime errors never leave the preview as a blank page. */
class RootErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string; stack: string }
> {
  state = { hasError: false, message: "", stack: "" };
  static getDerivedStateFromError(error: Error) {
    return {
      hasError: true,
      message: error.message || "Unknown runtime error",
      stack: error.stack || "",
    };
  }
  componentDidCatch(err: Error) {
    console.error("[WebContainer preview] Root crash:", err);
  }
  render() {
    if (this.state.hasError) {
      if (isModuleLoadError(this.state.message)) {
        return (
          <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background p-6 text-center text-foreground">
            <p className="text-sm font-semibold">تعذر الاتصال</p>
            <p className="text-muted-foreground max-w-xs text-xs leading-6">
              تحقق من اتصالك بالإنترنت ثم أعد المحاولة.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="bg-foreground text-background hover:bg-foreground/85 rounded-none border border-border px-5 py-2.5 text-xs font-medium transition-colors"
            >
              إعادة المحاولة
            </button>
          </div>
        );
      }
      return (
        <div className="min-h-screen flex items-center justify-center bg-background text-foreground p-6">
          <div className="max-w-lg text-center">
            <p className="text-sm font-semibold">Preview runtime error</p>
            <p className="mt-2 text-xs text-muted-foreground break-words">
              {this.state.message}
            </p>
            {this.state.stack && (
              <pre className="mt-3 text-left text-[10px] leading-4 text-muted-foreground/80 max-h-40 overflow-auto rounded border border-border/60 p-2">
                {this.state.stack}
              </pre>
            )}
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const convex = new ConvexReactClient(import.meta.env.VITE_CONVEX_URL as string);



function RouteSyncer() {
  const location = useLocation();
  useEffect(() => {
    window.parent.postMessage(
      { type: "iframe-route-change", path: location.pathname },
      "*",
    );
  }, [location.pathname]);

  useEffect(() => {
    function handleMessage(event: MessageEvent) {
      if (event.data?.type === "navigate") {
        if (event.data.direction === "back") window.history.back();
        if (event.data.direction === "forward") window.history.forward();
      }
    }
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  return null;
}


createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RootErrorBoundary>
      <ToolbarErrorBoundary>
        <VlyToolbar />
      </ToolbarErrorBoundary>
      <ConvexAuthProvider client={convex}>
        <LanguageProvider>
          <CartProvider>
            <BrowserRouter>
                <RouteSyncer />
                <Suspense fallback={<RouteLoading />}>
                  <Routes>
                    <Route element={<StoreLayout />}>
                      <Route path="/" element={<Landing />} />
                      <Route path="/shop" element={<Shop />} />
                      <Route path="/category/:slug" element={<CategoryPage />} />
                      <Route path="/product/:id" element={<ProductDetails />} />
                    </Route>
                    <Route path="/admin" element={<Admin />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </Suspense>
            </BrowserRouter>
          </CartProvider>
        </LanguageProvider>
        <Toaster />
      </ConvexAuthProvider>
    </RootErrorBoundary>
  </StrictMode>,
);
