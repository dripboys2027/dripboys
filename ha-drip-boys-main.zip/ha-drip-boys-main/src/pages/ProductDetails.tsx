import { useQuery } from "convex/react";
import {
  ArrowLeft,
  Minus,
  Plus,
  Ruler,
  ShieldCheck,
  Truck,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router";
import { toast } from "sonner";

import { api } from "@/convex/_generated/api";
import { ProductFormDialog } from "@/components/store/AddProductDialog";
import { AdminPencil } from "@/components/store/AdminEdit";
import { Badge, ProductImage, SectionHeading } from "@/components/store/bits";
import { ProductCard } from "@/components/store/ProductCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useStoreClock } from "@/hooks/use-store-clock";
import { pickLang, useI18n } from "@/lib/i18n";
import {
  UNKNOWN_COLOR,
  colorLabel,
  colorSwatch,
  formatDA,
  isHiddenFromStore,
  liveCategoryLabel,
  sizeLabel,
} from "@/lib/store-data";
import { flyToCart, useCart } from "@/lib/store-state";
import type { Product } from "@/lib/store-types";
import { cn } from "@/lib/utils";

/** Pencil on the product page that re-opens the full product form. */
function ProductPageEditButton({ product }: { product: Product }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);

  return (
    <>
      <AdminPencil
        label={t("admin.editProduct")}
        onClick={() => setOpen(true)}
        tone="dark"
      />
      <ProductFormDialog
        open={open}
        onOpenChange={setOpen}
        product={product}
        defaultCategory={product.category}
      />
    </>
  );
}

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const { t, lang, isAr } = useI18n();
  const product = useQuery(api.catalog.getProduct, { id: id ?? "" });
  const related = useQuery(api.catalog.listProducts);
  const categoryRows = useQuery(api.catalog.listCategories);

  const { addItem, openCart } = useCart();
  const galleryRef = useRef<HTMLDivElement>(null);
  /* Once a sold-out product's 24 hours are over its page leaves the site too. */
  const now = useStoreClock();
  const hidden = product ? isHiddenFromStore(product, now) : false;

  const [activeImage, setActiveImage] = useState(0);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (!product) return;
    setActiveImage(0);
    setQuantity(1);
    setColor(product.colors[0] ?? "");
    setSize("");
  }, [product]);

  /* A colour switch re-checks the size: the previous pick may be sold out
     for the new colour, and the gallery jumps to that colour's photo. */
  useEffect(() => {
    if (!product) return;
    const stillOk = product.sizes.find(
      (item) => item.label === size && item.available &&
        !soldOutForColor.has(item.label),
    );
    if (!stillOk) {
      const first = product.sizes.find(
        (item) => item.available && !soldOutForColor.has(item.label),
      );
      setSize(first?.label ?? "");
    }
    // The photo order is: one photo per picked colour, then the rest — so the
    // selected colour's photo is its index in the colours list.
    const colorIndex = product.colors.filter(Boolean).indexOf(color);
    if (colorIndex >= 0 && colorIndex < product.images.length) {
      setActiveImage(colorIndex);
    } else {
      setActiveImage(0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [color, product]);

  const relatedProducts = useMemo(() => {
    if (!product || !related) return [];
    return related
      .filter(
        (item) =>
          item.category === product.category &&
          item._id !== product._id &&
          !isHiddenFromStore(item, now),
      )
      .slice(0, 4);
  }, [product, related, now]);

  /**
   * Sizes sold out for the colour currently selected. A colour with no entry
   * (or no colour picked yet) falls back to the global availability only.
   * Must stay before any early return so the hook order never changes.
   */
  const soldOutForColor = useMemo(() => {
    if (!color || !product) return new Set<string>();
    const row = (product.soldOutByColor ?? []).find(
      (entry) => entry.color.toLowerCase() === color.toLowerCase(),
    );
    return new Set(row?.sizes ?? []);
  }, [product, color]);

  if (product === undefined) {
    return (
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2">
        <Skeleton className="h-[520px] rounded-3xl" />
        <div className="space-y-4">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-6 w-1/3" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-12 w-1/2" />
        </div>
      </div>
    );
  }

  /* Not found — or sold out for more than 24h, which removes it from the site. */
  if (product === null || hidden) {
    return (
      <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-4 px-4 py-24 text-center">
        <p className="text-lg font-semibold">{t("product.notFound")}</p>
        <Button asChild variant="outline">
          <Link to="/shop">{t("product.backToShop")}</Link>
        </Button>
      </div>
    );
  }

  const name = pickLang(product.nameAr, product.nameEn, lang);

  /** A size is buyable when it is globally available AND not sold out in the
   *  selected colour. Without a colour, only the global rule applies. */
  const sizeAvailable = (label: string, globallyAvailable: boolean) =>
    globallyAvailable && !soldOutForColor.has(label) && !product.soldOut;

  const selectableSizes = product.sizes.filter((item) =>
    sizeAvailable(item.label, item.available),
  );
  const headingClass = cn(
    "text-xs font-medium",
    isAr ? "tracking-[0.08em]" : "tracking-[0.16em] uppercase",
  );

  function handleAdd(openAfter = false) {
    if (!size) {
      toast.error(t("product.chooseSize"));
      return;
    }
    addItem(
      {
        productId: product!._id,
        nameAr: product!.nameAr,
        nameEn: product!.nameEn,
        price: product!.price,
        size,
        color: color || "—",
        image: product!.images[0] ?? "",
        deliveryFee: product!.deliveryFee,
      },
      quantity,
    );
    flyToCart(galleryRef.current, product!.images[0]);
    if (openAfter) {
      openCart();
    } else {
      toast.success(t("product.added"));
    }
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6">
      <nav className="text-muted-foreground flex flex-wrap items-center gap-2 text-xs">
        <Link to="/" className="hover:text-foreground">
          {t("common.home")}
        </Link>
        <span>/</span>
        <Link to="/shop" className="hover:text-foreground">
          {t("common.shop")}
        </Link>
        <span>/</span>
        <span className="text-foreground">{name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="relative overflow-hidden rounded-3xl border border-border/70 bg-muted">
            <div className="aspect-4/5">
              <ProductImage
                src={product.images[activeImage] ?? product.images[0]}
                alt={name}
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
            </div>
            {product.soldOut ? (
              <div className="absolute inset-0 grid place-items-center bg-background/70 backdrop-blur-[2px]">
                <Badge variant="soldout" className="px-4 py-2 text-[11px]">
                  {t("product.soldOut")}
                </Badge>
              </div>
            ) : null}
          </div>

          {product.images.length > 1 ? (
            <div className="mt-4 flex gap-3">
              {product.images.map((image, index) => (
                <button
                  key={image + index}
                  type="button"
                  aria-label={t("product.imageAlt", { n: index + 1 })}
                  onClick={() => setActiveImage(index)}
                  className={cn(
                    "size-20 overflow-hidden rounded-xl border transition-all",
                    activeImage === index
                      ? "border-foreground"
                      : "border-border/70 opacity-70 hover:opacity-100",
                  )}
                >
                  <ProductImage src={image} alt={name} sizes="80px" />
                </button>
              ))}
            </div>
          ) : null}
        </div>

        {/* Info */}
        <div>
          <p
            className={cn(
              "text-muted-foreground text-[10px]",
              isAr ? "tracking-[0.08em]" : "tracking-[0.3em] uppercase",
            )}
          >
            {liveCategoryLabel(categoryRows, product.category, lang)}
          </p>
          <div className="mt-3 flex items-center gap-3">
            <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
              {name}
            </h1>
            {/* Admin only: every value of this product, editable in place. */}
            <ProductPageEditButton product={product} />
          </div>

          <div className="mt-5 flex items-center gap-3">
            <span className="text-2xl font-semibold">{formatDA(product.price)}</span>
            {product.oldPrice ? (
              <span className="text-muted-foreground text-sm line-through">
                {formatDA(product.oldPrice)}
              </span>
            ) : null}
            {product.oldPrice ? (
              <Badge variant="muted">
                {t("product.save", {
                  amount: formatDA(product.oldPrice - product.price),
                })}
              </Badge>
            ) : null}
          </div>

          {/* Colors */}
          <div className="mt-8">
            <p className={headingClass}>{t("product.color")}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {product.colors.filter(Boolean).length === 0 ? (
                <span className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs">
                  <span
                    className="size-3.5 rounded-full border border-border"
                    style={{ background: colorSwatch(UNKNOWN_COLOR) }}
                  />
                  {t("product.unknownColor")}
                </span>
              ) : (
                product.colors.filter(Boolean).map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setColor(option)}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-xs transition-colors",
                      color === option
                        ? "border-foreground bg-foreground text-background"
                        : "border-border hover:border-foreground/40",
                    )}
                  >
                    <span
                      className="size-3.5 rounded-full border border-border/60"
                      style={{ background: colorSwatch(option) }}
                    />
                    {colorLabel(option, lang)}
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Sizes — filtered by the selected colour's stock */}
          <div className="mt-6">
            <div className="flex items-center justify-between">
              <p className={headingClass}>{t("product.size")}</p>
              <span className="text-muted-foreground text-[11px]">
                {t("product.sizesAvailable", { n: selectableSizes.length })}
              </span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {product.sizes.map((item) => {
                const ok = sizeAvailable(item.label, item.available);
                return (
                  <button
                    key={item.label}
                    type="button"
                    disabled={!ok}
                    onClick={() => setSize(item.label)}
                    className={cn(
                      "relative min-w-14 overflow-hidden rounded-xl border px-4 py-2.5 text-sm transition-colors",
                      size === item.label
                        ? "border-foreground bg-foreground text-background"
                        : "border-border hover:border-foreground/40",
                      !ok &&
                        "text-destructive border-destructive/50 cursor-not-allowed bg-destructive/5 hover:border-destructive/50",
                    )}
                  >
                    {sizeLabel(item.label, lang)}
                    {/* Unavailable size: a red diagonal slash across the whole
                        chip, not just a red colour. */}
                    {!ok ? (
                      <span
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-0 grid place-items-center overflow-hidden rounded-[inherit]"
                      >
                        <span className="bg-destructive block h-[2px] w-[180%] -rotate-[24deg]" />
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quantity stepper sits above the action buttons, centered */}
          <div className="mt-8 flex justify-center">
            <div className="flex items-center gap-1 rounded-full border border-border px-2 py-1">
              <button
                type="button"
                aria-label={t("product.quantityMinus")}
                onClick={() => setQuantity((value) => Math.max(1, value - 1))}
                className="grid size-8 place-items-center rounded-full hover:bg-muted"
              >
                <Minus className="size-4" />
              </button>
              <span className="w-8 text-center text-sm font-medium">{quantity}</span>
              <button
                type="button"
                aria-label={t("product.quantityPlus")}
                onClick={() => setQuantity((value) => value + 1)}
                className="grid size-8 place-items-center rounded-full hover:bg-muted"
              >
                <Plus className="size-4" />
              </button>
            </div>
          </div>

          {/* Add to cart / buy now — one tight row */}
          <div className="mt-3 flex flex-nowrap items-center gap-2 sm:gap-3 sm:flex-wrap">
            <Button
              className="h-12 flex-1 px-3 text-xs sm:px-6 sm:text-sm"
              disabled={product.soldOut}
              onClick={() => handleAdd(false)}
            >
              {t("product.addToCart")}
            </Button>
            <Button
              variant="outline"
              className="h-12 flex-1 px-3 text-xs sm:px-6 sm:text-sm"
              disabled={product.soldOut}
              onClick={() => handleAdd(true)}
            >
              {t("product.buyNow")}
            </Button>
          </div>

          <div className="mt-8 grid gap-3 rounded-2xl border border-border/70 p-4 text-xs sm:grid-cols-3">
            <span className="flex items-center gap-2">
              <Truck className="size-4 shrink-0" />
              {t("product.delivery")}
            </span>
            <span className="flex items-center gap-2">
              <ShieldCheck className="size-4 shrink-0" />
              {t("product.cod")}
            </span>
            <span className="flex items-center gap-2">
              <Ruler className="size-4 shrink-0" />
              {size
                ? t("product.yourSize", { size: sizeLabel(size, lang) })
                : t("product.sizeGuideHint")}
            </span>
          </div>
        </div>
      </div>

      {/* Related --------------------------------------------------------- */}
      {relatedProducts.length > 0 ? (
        <section className="mt-16">
          <SectionHeading
            eyebrow={t("product.relatedEyebrow")}
            title={t("product.related")}
          />
          <div className="mt-6 grid grid-cols-2 gap-5 lg:grid-cols-4">
            {relatedProducts.map((item, index) => (
              <ProductCard key={item._id} product={item} index={index} />
            ))}
          </div>
          <Button asChild variant="outline" className="mt-8">
            <Link to="/shop">
              {t("common.allProducts")}
              <ArrowLeft className={cn("size-4", !isAr && "rotate-180")} />
            </Link>
          </Button>
        </section>
      ) : null}
    </div>
  );
}
